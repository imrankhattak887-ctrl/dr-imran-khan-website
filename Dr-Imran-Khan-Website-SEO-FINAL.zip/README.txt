DR. IMRAN KHAN WEBSITE — VERCEL READY

Upload this ZIP to Vercel as a static site. No build command is required; index.html is the entry point.

Contact: 0332 4858838
Locations: G-10/1, G-8 Markaz, and MSK Tower, Ghori VIP Town, Islamabad

Instagram/Facebook profile URLs were not supplied in the final source material, so those labels are intentionally non-clickable. TikTok is linked to @doctor_imran01.

The booking form opens WhatsApp with the submitted details.
Google Maps links are search links where an exact street address was not supplied.

SEO note: sitemap.xml uses the final public domain. Canonical, Open Graph, Twitter metadata, MedicalBusiness schema and FAQ schema are configured for https://drimrankhanclinic.com/.
